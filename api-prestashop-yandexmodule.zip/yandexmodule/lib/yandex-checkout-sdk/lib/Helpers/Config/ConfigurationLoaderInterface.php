<?php

namespace YaMoney\Helpers\Config;

interface ConfigurationLoaderInterface
{
    public function getConfig();
}