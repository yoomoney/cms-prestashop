<?php

namespace YaMoney\Request\Payments;

/**
 * Класс объекта ответа, возвращаемого API при запросе конкретного платежа
 *
 * @package YaMoney\Request\Payments
 */
class PaymentResponse extends AbstractPaymentResponse
{}